#ifndef RKQS_H
#define RKQS_H

#include "gday.h"


void rkqs(double [], double [], int, double *, double, double,
          double [], double *, double *,
          double, double, double, double, double, nrutil *,
          void (*)(double, double [], double [], double, double, double,
                   double, double));



#endif /* RKQS_H */
