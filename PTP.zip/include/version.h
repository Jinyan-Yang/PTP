//#ifndef VER_H
//#define VER_H
//
//extern const char * build_git_time;
//extern const char * build_git_sha;
//
//
//#endif /* VER_H */
