#ifndef RKCK_H
#define RKCK_H

#include "gday.h"


void rkck(double [], double [], int, double, double, double [],
          double [], double, double, double, double, double, nrutil *,
	      void (*)(double, double [], double [], double, double, double,
                   double, double));


#endif /* RKCK_H */
