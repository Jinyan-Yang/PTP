#ifndef READ_PARAM_H
#define READ_PARAM_H

#include "gday.h"
#include "utilities.h"



int  parse_ini_file(control *, params *, state *);
int  handler(char *, char *, char *, control *, params *, state *);

#endif /* READ_PARAM_H */
